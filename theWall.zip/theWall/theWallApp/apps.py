from django.apps import AppConfig


class ThewallappConfig(AppConfig):
    name = 'theWallApp'
